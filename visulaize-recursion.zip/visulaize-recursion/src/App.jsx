import { useState } from 'react'
import InputComponent from './InputComponent'
import RecursiveBlock from './RecursiveBlock'
import { InputProvider } from './InputContext'
import './App.css'

// there are many different "n's"... and theyre all called n, but there are MANY OF THEM
// does the entire thing need to be wrapped in a setTimeout?

export default function App() {
  const [ready, setReady] = useState(false)
  const [userInput, setUserInput] = useState(['tyler','myers']);
  const [wordOne, setWordOne] = useState('');
  const [wordTwo, setWordTwo] = useState('');
  const [wordThree, setWordThree] = useState('');
  const [wordFour, setWordFour] = useState('');

  return (
    <>
        <input id="userInputOne" type="text" value={wordOne} onChange={(e) => setWordOne(e.target.value)}/> 
        <input id="userInputTwo" type="text" value={wordTwo} onChange={(e) => setWordTwo(e.target.value)}/> 
        <input id="userInputThree" type="text" value={wordThree} onChange={(e) => setWordThree(e.target.value)}/> 
        <input id="userInputFour" type="text" value={wordFour} onChange={(e) => setWordFour(e.target.value)}/> 
      <InputProvider value={userInput}>
        <br>
        </br>
          {userInput}
          Submit:
        <button onClick={() => {setReady(true); setUserInput([wordOne, wordTwo, wordThree, wordFour])}}></button>
        {ready ? <RecursiveBlock /> : null}
      </InputProvider>
    </>
  )
}
