import { useContext } from 'react'
import InputContext from './InputContext'

export default function InputComponent() {
    const [userInput, setUserInput] = useContext(InputContext);
    function enter(e) {
      setUserInput(e.target.value)
    }

    return (
    <>
      <br></br> 
      <br></br>  
      <label htmlFor="userInput">Enter words up to 5 letters in length:
        <input id="userInput" type="text" value={userInput} onChange={enter}/> 
      </label>
    </>
    )
}