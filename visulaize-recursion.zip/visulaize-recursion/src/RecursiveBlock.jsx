import { useState, useContext,useEffect, useRef } from 'react'
import InputContext from './InputContext'
import { reverseBothSnippet, reverseStringSnippet } from './utils'

export default function RecursiveBlock() {
    const userInput = useContext(InputContext);
    const [done, setDone] = useState(false)
    const reffer = useRef([])
    const arrayReffer = useRef([])
    const reffer2 = useRef([])
    const arrayReffer2 = useRef([])
    const finished = useRef(false)
    const [halved, setHalved] = useState([])
    const [halved2, setHalved2] = useState([])



    // arrayAndStringReverse(userInput)
    arrayAndStringReverse(userInput)

    const mappedReffer = reffer.current.map(item => <div>{item}</div>)
    const mappedReffer2 = arrayReffer.current.map(item => <div>{item}</div>)

    // console.log

    useEffect(() => {
        for (let i=0; i < (mappedReffer.length/2); i++) {
            console.log('hello')
            setTimeout(setHalved(prev=>[...prev, mappedReffer[i]]),1000)
        }
    },[done])

    useEffect(() => {
        for (let i=0; i < (mappedReffer2.length/2); i++) {
            console.log('hello')
            setTimeout(setHalved2(prev=>[...prev, mappedReffer2[i]]),1000)
        }
    },[done])
    
    function stringReverse(str) {
        if (str.length < 1) {
            finished.current = true
            console.log(finished.current)
            // console.log(str)
            
              return str;
          }
          useEffect(() => {
            reffer.current.push(reverseStringSnippet(str))
            reffer2.current.push(str)
          }, [str])
          return stringReverse(str.slice(1)) + str.charAt(0)
    }
        
    function arrayAndStringReverse(arr) {
        if (arr.length < 1) {
            // setFinished(true)
            // console.log(arr)
            return arr
        }
        useEffect(() => {
            arrayReffer.current.push(reverseBothSnippet([arr]));
            arrayReffer2.current.push([arr]);
          }, [arr])

        return arrayAndStringReverse(arr.slice(1)).concat(stringReverse(arr[0]))
    }

    return (
        <>
            <button onClick={() => setDone(true)}></button>
            {`${finished.current}`}
            <div className="wrapper">          
                {halved}
                {halved2}
                {console.log(arrayReffer2.current)}
            </div>
        </>
    )
}
