export function reverseBothSnippet(arrVal) { 
    const middle = `arrayReverse([${arrVal}])`
    const end = `.slice(1))
    .concat(stringReverse([${arrVal[0]}]))
    }`
    const first = `
    function reverseBoth([${arrVal}]) {
        if (![${arrVal}].length) {
            return [${arrVal}]
        }
        return `
    return (
        <pre className="reverse-both">
            {first}
            <code><strong>{middle}</strong></code>
            {end}
        </pre> 
    ) 
}

export function reverseStringSnippet(strVal) {
    const middle = `stringReverse("${strVal}")`
    const end = `+ strVal.charAt(0): "${strVal.charAt(0)}"
    }`
    const first = `
        function stringReverse("${strVal}") {
            if ("${strVal}".length < 1) {
                return "${strVal}";
        }
        return `
    return (
        <pre className="reverse-string">
            {first}
            <code><strong>{middle}</strong></code>
            {end}
        </pre>    
    )
}

